# 躲避車遊戲

[![hackmd-github-sync-badge](https://hackmd.io/xL1_VsNTTqmw_OGbGwKwoQ/badge)](https://hackmd.io/xL1_VsNTTqmw_OGbGwKwoQ)
![狀態](https://img.shields.io/badge/status-success-green)

**課程:** 嘉大資工課外自學讀書會  第二期課程 - 跨平台圖形化程式開發  
**題目:** 躲避車遊戲開發

**開發平台:** Qt5  
**程式語言:** C++

> 此遊戲可自行編譯至 Windows、Linux、Android 等平台執行

## 遊戲方式
透過鍵盤方向鍵控制賽車上下移動，在時間結束前躲過所有的障礙物即可過關。  
按下鍵盤空白鍵可暫停/開始遊戲。

## 遊戲畫面
![](https://i.imgur.com/IGuoYap.jpg)

###### tags: `讀書會`